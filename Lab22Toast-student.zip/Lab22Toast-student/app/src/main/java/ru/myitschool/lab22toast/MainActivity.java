package ru.myitschool.lab22toast;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;


public class MainActivity extends Activity {
    private static int count = -1;
    private static int flag = -1;

    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(getApplicationContext(), R.string.ncreate, Toast.LENGTH_LONG).show();
        if(flag != getResources().getConfiguration().orientation){
            count++;
        }
        flag=getResources().getConfiguration().orientation;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(getApplicationContext(), R.string.nstart, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(getApplicationContext(), R.string.nresume, Toast.LENGTH_LONG).show();
    }

    /* @Override
     protected void onPause() {
         super.onPause();
         Toast.makeText(this, R.string.npause, Toast.LENGTH_LONG).show();
     }

     @Override
     protected void onStop() {
         super.onStop();
         Toast.makeText(this, R.string.nstop, Toast.LENGTH_LONG).show();
     }
     @Override
     protected void onRestart(){
         super.onRestart();
         Toast.makeText(this, R.string.nrestart, Toast.LENGTH_LONG).show();
     }*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (count % 2 == 0) {
            Toast.makeText(getApplicationContext(), R.string.ndestroy, Toast.LENGTH_LONG).show();
            System.out.println("I am working destroy");
        }
    }
}